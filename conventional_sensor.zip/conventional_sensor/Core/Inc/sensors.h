/*
 * sensors.h
 *
 *  Created on: Sep 11, 2024
 *      Author: alexiy
 */

#ifndef INC_SENSORS_H_
#define INC_SENSORS_H_

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "ADS131M04_reg.h"
#include "ADIS16475_reg.h"
#include "stm32f4xx_hal.h"
#include "stm32f4xx_hal_tim.h"

// Struct definition
typedef struct {

	// ADC SPI Interface
	SPI_HandleTypeDef *ADS131M04_SPI;
	GPIO_TypeDef *ADS131M04_CS_Bank;
	uint16_t ADS131M04_CS_Pin;

	// Reset pin
	GPIO_TypeDef *ADS131M04_RESET_Bank;
	uint16_t ADS131M04_RESET_Pin;

	// DRDY pin - Interrupt? Bank not needed
	GPIO_TypeDef *ADS131M04_DRDY_Bank;
	uint16_t ADS131M04_DRDY_INT;

	// CLK pin
	TIM_HandleTypeDef *ADS131M04_CLK_TIM;
	uint32_t ADS131M04_CLK_CH;

	uint8_t ADS131M04_tx[18];
	uint8_t ADS131M04_rx[18];

	int32_t ADS131M04_data[4];

	// IMU SPI Interface
	SPI_HandleTypeDef *ADIS16475_SPI;
	GPIO_TypeDef *ADIS16475_CS_Bank;
	uint16_t ADIS16475_CS_Pin;

	// Reset pin
	GPIO_TypeDef *ADIS16475_RESET_Bank;
	uint16_t ADIS16475_RESET_Pin;

	// Data ready - used for interrupt
	GPIO_TypeDef *ADIS16475_DRDY_Bank;
	uint16_t ADIS16475_DRDY_INT;

	// SYNC pin
	GPIO_TypeDef *ADIS16475_SYNC_Bank;
	uint32_t ADIS16475_SYNC_Pin;

	uint8_t ADIS16475_tx[22];
	uint8_t ADIS16475_rx[22];

	int16_t ADIS16475_data[10];

	// Transmit array
	uint8_t *USB_tx;
	uint8_t USB_tx_1[1024];
	uint8_t USB_tx_2[1024];
	uint8_t USB_tx_track;
	uint16_t USB_tx_index;
	uint8_t USB_busy_flag;

	// uSD array
	uint8_t *uSD_tx;
	uint8_t uSD_tx_1[4096];
	uint8_t uSD_tx_2[4096];
	uint8_t uSD_tx_track;
	uint16_t uSD_tx_index;
	uint16_t uSD_file_counter;
	uint32_t uSD_file_index;

	// Print flag
	uint8_t USB_flag;
	uint8_t uSD_flag;

	// Init flag
	uint8_t is_init;

	// Random number
	uint16_t random_number;
} sensors;

// Unit Declaration
sensors sensorsx;

uint8_t init_sensors(sensors *Unit, SPI_HandleTypeDef *ADS131M04_SPI,
		GPIO_TypeDef *ADS131M04_CS_Bank, uint16_t ADS131M04_CS_Pin,
		GPIO_TypeDef *ADS131M04_RESET_Bank, uint16_t ADS131M04_RESET_Pin,
		GPIO_TypeDef *ADS131M04_DRDY_Bank, uint16_t ADS131M04_DRDY_INT,
		TIM_HandleTypeDef *ADS131M04_CLK_TIM, uint32_t ADS131M04_CLK_CH,
		SPI_HandleTypeDef *ADIS16475_SPI, GPIO_TypeDef *ADIS16475_CS_Bank,
		uint16_t ADIS16475_CS_Pin, GPIO_TypeDef *ADIS16475_RESET_Bank,
		uint16_t ADIS16475_RESET_Pin, GPIO_TypeDef *ADIS16475_DRDY_Bank,
		uint16_t ADIS16475_DRDY_INT, GPIO_TypeDef *ADIS16475_SYNC_Bank,
		uint32_t ADIS16475_SYNC_Pin, uint16_t random_number);

void read_ADC_reg(sensors *Unit, uint16_t register_number);
void write_ADC_reg(sensors *Unit, uint16_t register_number,
		uint16_t register_value);

void read_IMU_reg(sensors *Unit, uint16_t register_number);
void write_IMU_reg(sensors *Unit, uint16_t register_number,
		uint16_t register_value);

void read_ADC_values(sensors *Unit);
void read_IMU_values(sensors *Unit);

#endif /* INC_SENSORS_H_ */
