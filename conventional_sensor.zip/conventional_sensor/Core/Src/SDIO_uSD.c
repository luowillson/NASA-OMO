/*
 * SPI_uSD.c
 *
 *  Created on: Jul 28, 2024
 *      Author: alexiy
 */

#include "SDIO_uSD.h"
#include "fatfs.h"
#include "string.h"
#include "stdio.h"

FRESULT uSD_record_configuration(sensors *Unit) {
	uint8_t buffer[512] = { "\0" };
	uint8_t *pos = buffer;

	// Relevant ADC settings
	read_ADC_reg(Unit, REG_ID);
	pos += sprintf(pos, "ADC REG_ID: 0x%02x%02x, ", Unit->ADS131M04_rx[0],
			Unit->ADS131M04_rx[1]);

	read_ADC_reg(Unit, REG_CLOCK);
	pos += sprintf(pos, "ADC REG_CLOCK: 0x%02x%02x, ", Unit->ADS131M04_rx[0],
			Unit->ADS131M04_rx[1]);

	read_ADC_reg(Unit, REG_CFG);
	pos += sprintf(pos, "ADC REG_CFG: 0x%02x%02x, ", Unit->ADS131M04_rx[0],
			Unit->ADS131M04_rx[1]);

	// Record ADC biases / offsets

	// Relevant IMU settings
	read_IMU_reg(Unit, PROD_ID);
	pos += sprintf(pos, "IMU PROD_ID: 0x%02x%02x, ", Unit->ADIS16475_rx[0],
			Unit->ADIS16475_rx[1]);

	read_IMU_reg(Unit, MSC_CTRL);
	pos += sprintf(pos, "IMU MSC_CTRL: 0x%02x%02x, ", Unit->ADIS16475_rx[0],
			Unit->ADIS16475_rx[1]);

	// Record IMU biases / offset

	pos += sprintf(pos, "Number: %u\r\n", Unit->random_number);

	// Reset buffers to all 0
	memset(Unit->ADIS16475_tx, 0, 25);
	memset(Unit->ADIS16475_rx, 0, 25);

	// Reset buffers to all 0
	memset(Unit->ADS131M04_tx, 0, 25);
	memset(Unit->ADS131M04_rx, 0, 25);

	// FIXME
	/*
	uSD_open("CONFIG.TXT");
	uSD_write("CONFIG.TXT", buffer, strlen(buffer));
	uSD_close();
	*/
}

FRESULT uSD_mount() {
	// Mount uSD card FS
	fresult = f_mount(&fs, "/", 1);
	if (fresult == FR_OK) {
		// Get free space on uSD card
		f_getfree("", &fre_clust, &pfs);
		uSD_close();
	} else {

		// In the event that it is not successful, loop repeatedly remounting the uSD card until it is mounted
		for (int i = 0; i < 10; i++) {
			FATFS_UnLinkDriver("/");
			MX_FATFS_Init();
			fresult = f_mount(&fs, "/", 1);
			// Get free space on uSD card
			f_getfree("", &fre_clust, &pfs);
		}

		if (fresult != FR_OK) {
			NVIC_SystemReset();
		}

		// Add entry to error buffer
		sprintf(error_buffer, "mount %luf%lu.dat, %lu\r\n",
				sensorsx.random_number, sensorsx.uSD_file_index,
				sensorsx.uSD_file_counter);
		uSD_open("ERROR.TXT");
		uSD_write("ERROR.TXT", error_buffer, strlen(error_buffer));
		uSD_close();
	}

	// Return result
	return fresult;
}

FRESULT uSD_open(uint8_t *file_name) {
	// Open file to write/ create a file if it doesn't exist
	fresult = f_open(&fil, file_name, FA_WRITE | FA_OPEN_APPEND);

	if (fresult != FR_OK) {
		uSD_mount();

		sprintf(error_buffer, "open %luf%lu.dat, %lu\r\n",
				sensorsx.random_number, sensorsx.uSD_file_index,
				sensorsx.uSD_file_counter);
		uSD_open("ERROR.TXT");
		uSD_write("ERROR.TXT", error_buffer, strlen(error_buffer));
		uSD_close();

		uSD_open(file_name);
	}

	return fresult;
}

FRESULT uSD_close() {
	// Close file
	fresult = f_close(&fil);

	return fresult;
}

FRESULT uSD_write(uint8_t *file_name, uint8_t *contents, uint16_t length) {
	// Obtain result from writing
	fresult = f_write(&fil, contents, length, NULL);

	// If the result is not FR_OK, remount the uSD card and reopen the file for writing
	if (fresult != FR_OK) {
		uSD_mount();

		sprintf(error_buffer, "write %luf%lu.dat, %lu\r\n",
				sensorsx.random_number, sensorsx.uSD_file_index,
				sensorsx.uSD_file_counter);
		uSD_open("ERROR.TXT");
		uSD_write("ERROR.TXT", error_buffer, strlen(error_buffer));
		uSD_close();

		uSD_open(file_name);
		uSD_write(file_name, contents, length);
	}

	return fresult;
}

