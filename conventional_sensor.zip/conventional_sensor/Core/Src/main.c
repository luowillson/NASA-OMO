/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "SDIO_uSD.h"
#include "usbd_cdc_if.h"
#include <stdio.h>
#include <string.h>

#include "sensors.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
RNG_HandleTypeDef hrng;

RTC_HandleTypeDef hrtc;

SD_HandleTypeDef hsd;
DMA_HandleTypeDef hdma_sdio_rx;
DMA_HandleTypeDef hdma_sdio_tx;

SPI_HandleTypeDef hspi1;
SPI_HandleTypeDef hspi2;
DMA_HandleTypeDef hdma_spi2_rx;
DMA_HandleTypeDef hdma_spi2_tx;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim9;
TIM_HandleTypeDef htim10;

/* USER CODE BEGIN PV */
uint8_t TxBuffer[250];
uint8_t flag = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_SPI1_Init(void);
static void MX_SPI2_Init(void);
static void MX_SDIO_SD_Init(void);
static void MX_TIM9_Init(void);
static void MX_TIM10_Init(void);
static void MX_RNG_Init(void);
static void MX_RTC_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
static void USB_CDC_Print(uint8_t *TxStr) {
	if (sensorsx.USB_busy_flag == 0) {
		sensorsx.USB_busy_flag = 1;
		CDC_Transmit_FS((uint8_t*) TxStr, 1024);
		sensorsx.USB_busy_flag = 0;
	}
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	sensorsx.is_init = 0;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
	MX_DMA_Init();
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_SPI1_Init();
  MX_SPI2_Init();
  MX_SDIO_SD_Init();
  MX_FATFS_Init();
  MX_USB_DEVICE_Init();
  MX_TIM9_Init();
  MX_TIM10_Init();
  MX_RNG_Init();
  MX_RTC_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */

	uint16_t random_number = HAL_RNG_GetRandomNumber(&hrng);

	// SDIO SD Card Initialization Code
	// FIXME
	// uSD_mount();

	// ADC + IMU Initialization Code
	init_sensors(&sensorsx, &hspi1, GPIOC, GPIO_PIN_5, GPIOB, GPIO_PIN_12,
	GPIOC, GPIO_PIN_4, &htim9, TIM_CHANNEL_2, &hspi2, GPIOC, GPIO_PIN_6, GPIOA,
	GPIO_PIN_10, GPIOA, GPIO_PIN_8, GPIOC, GPIO_PIN_7, random_number);

	// Initialization recording
	// This function was modified - FIXME
	uSD_record_configuration(&sensorsx);

	// Open first file to write to by setting name buffer
	// FIXME
	/*
	sprintf(file_name_buffer, "%luf%05lu.dat", sensorsx.random_number,
			sensorsx.uSD_file_index);
	uSD_open(file_name_buffer);
	*/

	// Timestamp generation
	HAL_TIM_Base_Start(&htim2);

	// Initialization complete
	sensorsx.is_init = 1;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1) {

		// FIXME
		/*
		if (sensorsx.USB_flag == 1) {
			if (sensorsx.USB_tx_track == 1) {
				USB_CDC_Print((uint8_t*) sensorsx.USB_tx_2);
			} else {
				USB_CDC_Print((uint8_t*) sensorsx.USB_tx_1);
			}
			sensorsx.USB_flag = 0;
		}
		*/

		// FIXME
		/*
		if (sensorsx.uSD_flag == 1) {
			sensorsx.uSD_flag = 2;
			if (sensorsx.uSD_tx_track == 1) {
				uSD_write(file_name_buffer, sensorsx.uSD_tx_2, 4096);
			} else {
				uSD_write(file_name_buffer, sensorsx.uSD_tx_1, 4096);
			}
			sensorsx.uSD_file_counter++;
			if (sensorsx.uSD_file_counter == 1024) {
				uSD_close();
				sensorsx.uSD_file_counter = 0;
				sensorsx.uSD_file_index++;
				sprintf(file_name_buffer, "%luf%05lu.dat",
						sensorsx.random_number, sensorsx.uSD_file_index);
				uSD_open(file_name_buffer);
			}
		}
		*/

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 5;
  RCC_OscInitStruct.PLL.PLLN = 120;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 5;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_RTC;
  PeriphClkInitStruct.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief RNG Initialization Function
  * @param None
  * @retval None
  */
static void MX_RNG_Init(void)
{

  /* USER CODE BEGIN RNG_Init 0 */

  /* USER CODE END RNG_Init 0 */

  /* USER CODE BEGIN RNG_Init 1 */

  /* USER CODE END RNG_Init 1 */
  hrng.Instance = RNG;
  if (HAL_RNG_Init(&hrng) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RNG_Init 2 */

  /* USER CODE END RNG_Init 2 */

}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */
  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = 127;
  hrtc.Init.SynchPrediv = 255;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief SDIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_SDIO_SD_Init(void)
{

  /* USER CODE BEGIN SDIO_Init 0 */

  /* USER CODE END SDIO_Init 0 */

  /* USER CODE BEGIN SDIO_Init 1 */

  /* USER CODE END SDIO_Init 1 */
  hsd.Instance = SDIO;
  hsd.Init.ClockEdge = SDIO_CLOCK_EDGE_RISING;
  hsd.Init.ClockBypass = SDIO_CLOCK_BYPASS_DISABLE;
  hsd.Init.ClockPowerSave = SDIO_CLOCK_POWER_SAVE_DISABLE;
  hsd.Init.BusWide = SDIO_BUS_WIDE_1B;
  hsd.Init.HardwareFlowControl = SDIO_HARDWARE_FLOW_CONTROL_DISABLE;
  hsd.Init.ClockDiv = 0;
  /* USER CODE BEGIN SDIO_Init 2 */

  /* USER CODE END SDIO_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_2EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_HIGH;
  hspi2.Init.CLKPhase = SPI_PHASE_2EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_32;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 60-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM9 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM9_Init(void)
{

  /* USER CODE BEGIN TIM9_Init 0 */

  /* USER CODE END TIM9_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM9_Init 1 */

  /* USER CODE END TIM9_Init 1 */
  htim9.Instance = TIM9;
  htim9.Init.Prescaler = 0;
  htim9.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim9.Init.Period = 15 - 1;
  htim9.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim9.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim9) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim9, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim9) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim9, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM9_Init 2 */

  /* USER CODE END TIM9_Init 2 */
  HAL_TIM_MspPostInit(&htim9);

}

/**
  * @brief TIM10 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM10_Init(void)
{

  /* USER CODE BEGIN TIM10_Init 0 */

  /* USER CODE END TIM10_Init 0 */

  /* USER CODE BEGIN TIM10_Init 1 */

  /* USER CODE END TIM10_Init 1 */
  htim10.Instance = TIM10;
  htim10.Init.Prescaler = 0;
  htim10.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim10.Init.Period = 65535;
  htim10.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim10.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim10) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM10_Init 2 */

  /* USER CODE END TIM10_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream3_IRQn);
  /* DMA1_Stream4_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);
  /* DMA2_Stream3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream3_IRQn);
  /* DMA2_Stream6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream6_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream6_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, SPI1_NSS_Pin|SPI2_NSS_Pin|ADIS_SYNC_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(ADS131M04_RST_GPIO_Port, ADS131M04_RST_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(ADIS_RST_GPIO_Port, ADIS_RST_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : CARD_DETECT_Pin */
  GPIO_InitStruct.Pin = CARD_DETECT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(CARD_DETECT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : ADS131M04_DRDY_Pin */
  GPIO_InitStruct.Pin = ADS131M04_DRDY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(ADS131M04_DRDY_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : SPI1_NSS_Pin SPI2_NSS_Pin ADIS_SYNC_Pin */
  GPIO_InitStruct.Pin = SPI1_NSS_Pin|SPI2_NSS_Pin|ADIS_SYNC_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : ADS131M04_RST_Pin */
  GPIO_InitStruct.Pin = ADS131M04_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(ADS131M04_RST_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : ADIS_DR_Pin */
  GPIO_InitStruct.Pin = ADIS_DR_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(ADIS_DR_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : ADIS_RST_Pin */
  GPIO_InitStruct.Pin = ADIS_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(ADIS_RST_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
	if (sensorsx.is_init == 1 && GPIO_Pin == sensorsx.ADS131M04_DRDY_INT) {
		HAL_GPIO_TogglePin(sensorsx.ADIS16475_SYNC_Bank,
				sensorsx.ADIS16475_SYNC_Pin);
		read_ADC_values(&sensorsx);
	}
	if (sensorsx.is_init == 1 && GPIO_Pin == sensorsx.ADIS16475_DRDY_INT) {
		read_IMU_values(&sensorsx);

	}
}

void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi) {
	if (hspi == sensorsx.ADIS16475_SPI) {
		HAL_GPIO_WritePin(sensorsx.ADIS16475_CS_Bank, sensorsx.ADIS16475_CS_Pin,
				GPIO_PIN_SET);

		sensorsx.ADIS16475_data[0] = ((sensorsx.ADIS16475_rx[2] << 8)
				| sensorsx.ADIS16475_rx[3]); // DIAG_STAT
		sensorsx.ADIS16475_data[1] = ((sensorsx.ADIS16475_rx[4] << 8)
				| sensorsx.ADIS16475_rx[5]); // X_GYRO_OUT
		sensorsx.ADIS16475_data[2] = ((sensorsx.ADIS16475_rx[6] << 8)
				| sensorsx.ADIS16475_rx[7]); // Y_GYRO_OUT
		sensorsx.ADIS16475_data[3] = ((sensorsx.ADIS16475_rx[8] << 8)
				| sensorsx.ADIS16475_rx[9]); // Z_GYRO_OUT
		sensorsx.ADIS16475_data[4] = ((sensorsx.ADIS16475_rx[10] << 8)
				| sensorsx.ADIS16475_rx[11]); 	// X_ACCL_OUT
		sensorsx.ADIS16475_data[5] = ((sensorsx.ADIS16475_rx[12] << 8)
				| sensorsx.ADIS16475_rx[13]); 	// Y_ACCL_OUT
		sensorsx.ADIS16475_data[6] = ((sensorsx.ADIS16475_rx[14] << 8)
				| sensorsx.ADIS16475_rx[15]); 	// Z_ACCL_OUT
		sensorsx.ADIS16475_data[7] = ((sensorsx.ADIS16475_rx[16] << 8)
				| sensorsx.ADIS16475_rx[17]); 	// TEMP_OUT
		sensorsx.ADIS16475_data[8] = ((sensorsx.ADIS16475_rx[18] << 8)
				| sensorsx.ADIS16475_rx[19]); 	// DATA_CNTR
		sensorsx.ADIS16475_data[9] = ((sensorsx.ADIS16475_rx[20] << 8)
				| sensorsx.ADIS16475_rx[21]); 	// checksum

		uint16_t integrity_test = sensorsx.ADIS16475_rx[2]
				+ sensorsx.ADIS16475_rx[3] + sensorsx.ADIS16475_rx[4]
				+ sensorsx.ADIS16475_rx[5] + sensorsx.ADIS16475_rx[6]
				+ sensorsx.ADIS16475_rx[7] + sensorsx.ADIS16475_rx[8]
				+ sensorsx.ADIS16475_rx[9] + sensorsx.ADIS16475_rx[10]
				+ sensorsx.ADIS16475_rx[11] + sensorsx.ADIS16475_rx[12]
				+ sensorsx.ADIS16475_rx[13] + sensorsx.ADIS16475_rx[14]
				+ sensorsx.ADIS16475_rx[15] + sensorsx.ADIS16475_rx[16]
				+ sensorsx.ADIS16475_rx[17] + sensorsx.ADIS16475_rx[18]
				+ sensorsx.ADIS16475_rx[19];

		// IMU data is 16 bit ints

		if (integrity_test == sensorsx.ADIS16475_data[9]) {
			int x = 0;
		}

		sensorsx.ADS131M04_data[0] = ((sensorsx.ADS131M04_rx[3] << 24)
				| (sensorsx.ADS131M04_rx[4] << 16)
				| (sensorsx.ADS131M04_rx[5] << 8)) >> 8;
		sensorsx.ADS131M04_data[1] = ((sensorsx.ADS131M04_rx[6] << 24)
				| (sensorsx.ADS131M04_rx[7] << 16)
				| (sensorsx.ADS131M04_rx[8] << 8)) >> 8;
		sensorsx.ADS131M04_data[2] = ((sensorsx.ADS131M04_rx[9] << 24)
				| (sensorsx.ADS131M04_rx[10] << 16)
				| (sensorsx.ADS131M04_rx[11] << 8)) >> 8;
		sensorsx.ADS131M04_data[3] = ((sensorsx.ADS131M04_rx[12] << 24)
				| (sensorsx.ADS131M04_rx[13] << 16)
				| (sensorsx.ADS131M04_rx[14] << 8)) >> 8;


		// FIXME
		/*
		// Always record data to uSD card
		// Record via uSD

		// Gyro x
		sensorsx.uSD_tx[0 + sensorsx.uSD_tx_index * 14] =
				sensorsx.ADIS16475_rx[4];
		sensorsx.uSD_tx[1 + sensorsx.uSD_tx_index * 14] =
				sensorsx.ADIS16475_rx[5];
		// Gyro y
		sensorsx.uSD_tx[2 + sensorsx.uSD_tx_index * 14] =
				sensorsx.ADIS16475_rx[6];
		sensorsx.uSD_tx[3 + sensorsx.uSD_tx_index * 14] =
				sensorsx.ADIS16475_rx[7];
		// Gyro z
		sensorsx.uSD_tx[4 + sensorsx.uSD_tx_index * 14] =
				sensorsx.ADIS16475_rx[8];
		sensorsx.uSD_tx[5 + sensorsx.uSD_tx_index * 14] =
				sensorsx.ADIS16475_rx[9];
		// Acc x
		sensorsx.uSD_tx[6 + sensorsx.uSD_tx_index * 14] =
				sensorsx.ADIS16475_rx[10];
		sensorsx.uSD_tx[7 + sensorsx.uSD_tx_index * 14] =
				sensorsx.ADIS16475_rx[11];
		// Acc y
		sensorsx.uSD_tx[8 + sensorsx.uSD_tx_index * 14] =
				sensorsx.ADIS16475_rx[12];
		sensorsx.uSD_tx[9 + sensorsx.uSD_tx_index * 14] =
				sensorsx.ADIS16475_rx[13];
		// Acc z
		sensorsx.uSD_tx[10 + sensorsx.uSD_tx_index * 14] =
				sensorsx.ADIS16475_rx[14];
		sensorsx.uSD_tx[11 + sensorsx.uSD_tx_index * 14] =
				sensorsx.ADIS16475_rx[15];
		// Temp
		sensorsx.uSD_tx[12 + sensorsx.uSD_tx_index * 14] =
				sensorsx.ADIS16475_rx[16];
		sensorsx.uSD_tx[13 + sensorsx.uSD_tx_index * 14] =
				sensorsx.ADIS16475_rx[17];

		// Add time stamp to data at index 4092-4095, if we are currently writing a new "page"?
		if (sensorsx.uSD_tx_index == 0) {
			sensorsx.uSD_tx[4092] = (TIM2->CNT) >> 24 & 0xFF;
			sensorsx.uSD_tx[4093] = (TIM2->CNT) >> 16 & 0xFF;
			sensorsx.uSD_tx[4094] = (TIM2->CNT) >> 8 & 0xFF;
			sensorsx.uSD_tx[4095] = (TIM2->CNT) & 0xFF;
		}

		sensorsx.uSD_tx_index++;

		if (sensorsx.uSD_tx_index == 292) {
			if (sensorsx.uSD_tx_track == 1) {
				sensorsx.uSD_tx_track = 2;
				sensorsx.uSD_tx = sensorsx.uSD_tx_2;
			} else {
				sensorsx.uSD_tx_track = 1;
				sensorsx.uSD_tx = sensorsx.uSD_tx_1;
			}
			sensorsx.uSD_tx_index = 0;
			sensorsx.uSD_flag = 1;
		}
		*/


		// Gyro x
		sensorsx.USB_tx[0 + 4 + sensorsx.USB_tx_index * 14] = sensorsx.ADIS16475_rx[4];
		sensorsx.USB_tx[1 + 4 + sensorsx.USB_tx_index * 14] = sensorsx.ADIS16475_rx[5];
		// Gyro y
		sensorsx.USB_tx[2 + 4 + sensorsx.USB_tx_index * 14] = sensorsx.ADIS16475_rx[6];
		sensorsx.USB_tx[3 + 4 + sensorsx.USB_tx_index * 14] = sensorsx.ADIS16475_rx[7];
		// Gyro z
		sensorsx.USB_tx[4 + 4 + sensorsx.USB_tx_index * 14] = sensorsx.ADIS16475_rx[8];
		sensorsx.USB_tx[5 + 4 + sensorsx.USB_tx_index * 14] = sensorsx.ADIS16475_rx[9];
		// Acc x
		sensorsx.USB_tx[6 + 4 + sensorsx.USB_tx_index * 14] = sensorsx.ADIS16475_rx[10];
		sensorsx.USB_tx[7 + 4 + sensorsx.USB_tx_index * 14] = sensorsx.ADIS16475_rx[11];
		// Acc y
		sensorsx.USB_tx[8 + 4 + sensorsx.USB_tx_index * 14] = sensorsx.ADIS16475_rx[12];
		sensorsx.USB_tx[9 + 4 + sensorsx.USB_tx_index * 14] = sensorsx.ADIS16475_rx[13];
		// Acc z
		sensorsx.USB_tx[10 + 4 + sensorsx.USB_tx_index * 14] = sensorsx.ADIS16475_rx[14];
		sensorsx.USB_tx[11 + 4 + sensorsx.USB_tx_index * 14] = sensorsx.ADIS16475_rx[15];
		// Temp
		sensorsx.USB_tx[12 + 4 + sensorsx.USB_tx_index * 14] = sensorsx.ADIS16475_rx[16];
		sensorsx.USB_tx[13 + 4 + sensorsx.USB_tx_index * 14] = sensorsx.ADIS16475_rx[17];

		// Add time stamp to data at index 1016-1019, if we are currently writing a new "page"?
		if (sensorsx.USB_tx_index == 0) {
			sensorsx.USB_tx[1016] = (TIM2->CNT) >> 24 & 0xFF;
			sensorsx.USB_tx[1017] = (TIM2->CNT) >> 16 & 0xFF;
			sensorsx.USB_tx[1018] = (TIM2->CNT) >> 8 & 0xFF;
			sensorsx.USB_tx[1019] = (TIM2->CNT) & 0xFF;
		}

		sensorsx.USB_tx_index++;

		// sensorsx.USB_flag = 1;

		if (sensorsx.USB_tx_index == 72) {
			if (sensorsx.USB_tx_track == 1) {
				sensorsx.USB_tx_track = 2;
				sensorsx.USB_tx = sensorsx.USB_tx_2;
			} else {
				sensorsx.USB_tx_track = 1;
				sensorsx.USB_tx = sensorsx.USB_tx_1;
			}
			sensorsx.USB_flag = 1;
			sensorsx.USB_tx_index = 0;
		}

//  	// Piezo x
//		sensorsx.uSD_tx[0 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADS131M04_rx[3];
//		sensorsx.uSD_tx[1 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADS131M04_rx[4];
//		sensorsx.uSD_tx[2 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADS131M04_rx[5];
//		// Piezo y
//		sensorsx.uSD_tx[3 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADS131M04_rx[6];
//		sensorsx.uSD_tx[4 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADS131M04_rx[7];
//		sensorsx.uSD_tx[5 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADS131M04_rx[8];
//		// Piezo z
//		sensorsx.uSD_tx[6 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADS131M04_rx[9];
//		sensorsx.uSD_tx[7 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADS131M04_rx[10];
//		sensorsx.uSD_tx[8 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADS131M04_rx[11];
//
//		// Gyro x
//		sensorsx.uSD_tx[9 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADIS16475_rx[4];
//		sensorsx.uSD_tx[10 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADIS16475_rx[5];
//		// Gyro y
//		sensorsx.uSD_tx[11 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADIS16475_rx[6];
//		sensorsx.uSD_tx[12 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADIS16475_rx[7];
//		// Gyro z
//		sensorsx.uSD_tx[13 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADIS16475_rx[8];
//		sensorsx.uSD_tx[14 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADIS16475_rx[9];
//		// Acc x
//		sensorsx.uSD_tx[15 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADIS16475_rx[10];
//		sensorsx.uSD_tx[16 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADIS16475_rx[11];
//		// Acc y
//		sensorsx.uSD_tx[17 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADIS16475_rx[12];
//		sensorsx.uSD_tx[18 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADIS16475_rx[13];
//		// Acc z
//		sensorsx.uSD_tx[19 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADIS16475_rx[14];
//		sensorsx.uSD_tx[20 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADIS16475_rx[15];
//		// Temp
//		sensorsx.uSD_tx[21 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADIS16475_rx[16];
//		sensorsx.uSD_tx[22 + sensorsx.uSD_tx_index * 23] =
//				sensorsx.ADIS16475_rx[17];
//
//		// Add time stamp to data at index 4080-4083, if we are currently writing a new "page"?
//		if (sensorsx.uSD_tx_index == 0) {
//			sensorsx.uSD_tx[4080] = (TIM2->CNT) >> 24 & 0xFF;
//			sensorsx.uSD_tx[4081] = (TIM2->CNT) >> 16 & 0xFF;
//			sensorsx.uSD_tx[4082] = (TIM2->CNT) >> 8 & 0xFF;
//			sensorsx.uSD_tx[4083] = (TIM2->CNT) & 0xFF;
//		}
//
//		sensorsx.uSD_tx_index++;
//
//		if (sensorsx.uSD_tx_index == 177) {
//			if (sensorsx.uSD_tx_track == 1) {
//				sensorsx.uSD_tx_track = 2;
//				sensorsx.uSD_tx = sensorsx.uSD_tx_2;
//			} else {
//				sensorsx.uSD_tx_track = 1;
//				sensorsx.uSD_tx = sensorsx.uSD_tx_1;
//			}
//			sensorsx.uSD_tx_index = 0;
//			sensorsx.uSD_flag = 1;
//		}
//
//
//		// Piezo x
//		sensorsx.USB_tx[0 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADS131M04_rx[3];
//		sensorsx.USB_tx[1 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADS131M04_rx[4];
//		sensorsx.USB_tx[2 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADS131M04_rx[5];
//		// Piezo y
//		sensorsx.USB_tx[3 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADS131M04_rx[6];
//		sensorsx.USB_tx[4 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADS131M04_rx[7];
//		sensorsx.USB_tx[5 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADS131M04_rx[8];
//		// Piezo z
//		sensorsx.USB_tx[6 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADS131M04_rx[9];
//		sensorsx.USB_tx[7 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADS131M04_rx[10];
//		sensorsx.USB_tx[8 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADS131M04_rx[11];
//
//		// Gyro x
//		sensorsx.USB_tx[9 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADIS16475_rx[4];
//		sensorsx.USB_tx[10 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADIS16475_rx[5];
//		// Gyro y
//		sensorsx.USB_tx[11 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADIS16475_rx[6];
//		sensorsx.USB_tx[12 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADIS16475_rx[7];
//		// Gyro z
//		sensorsx.USB_tx[13 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADIS16475_rx[8];
//		sensorsx.USB_tx[14 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADIS16475_rx[9];
//		// Acc x
//		sensorsx.USB_tx[15 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADIS16475_rx[10];
//		sensorsx.USB_tx[16 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADIS16475_rx[11];
//		// Acc y
//		sensorsx.USB_tx[17 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADIS16475_rx[12];
//		sensorsx.USB_tx[18 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADIS16475_rx[13];
//		// Acc z
//		sensorsx.USB_tx[19 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADIS16475_rx[14];
//		sensorsx.USB_tx[20 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADIS16475_rx[15];
//		// Temp
//		sensorsx.USB_tx[21 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADIS16475_rx[16];
//		sensorsx.USB_tx[22 + 4 + sensorsx.USB_tx_index * 23] = sensorsx.ADIS16475_rx[17];
//
//		// Add time stamp to data at index 1016-1019, if we are currently writing a new "page"?
//		if (sensorsx.USB_tx_index == 0) {
//			sensorsx.USB_tx[1016] = (TIM2->CNT) >> 24 & 0xFF;
//			sensorsx.USB_tx[1017] = (TIM2->CNT) >> 16 & 0xFF;
//			sensorsx.USB_tx[1018] = (TIM2->CNT) >> 8 & 0xFF;
//			sensorsx.USB_tx[1019] = (TIM2->CNT) & 0xFF;
//		}
//
//		sensorsx.USB_tx_index++;
//
//		// sensorsx.USB_flag = 1;
//
//		if (sensorsx.USB_tx_index == 44) {
//			if (sensorsx.USB_tx_track == 1) {
//				sensorsx.USB_tx_track = 2;
//				sensorsx.USB_tx = sensorsx.USB_tx_2;
//			} else {
//				sensorsx.USB_tx_track = 1;
//				sensorsx.USB_tx = sensorsx.USB_tx_1;
//			}
//			sensorsx.USB_flag = 1;
//			sensorsx.USB_tx_index = 0;
//		}
	}
}
/* USER CODE END 4 */

 /**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
