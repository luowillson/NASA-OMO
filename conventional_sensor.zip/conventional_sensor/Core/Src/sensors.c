/*
 * sensors.c
 *
 *  Created on: Sep 11, 2024
 *      Author: alexiy
 */

#include "sensors.h"

uint8_t init_sensors(sensors *Unit, SPI_HandleTypeDef *ADS131M04_SPI,
		GPIO_TypeDef *ADS131M04_CS_Bank, uint16_t ADS131M04_CS_Pin,
		GPIO_TypeDef *ADS131M04_RESET_Bank, uint16_t ADS131M04_RESET_Pin,
		GPIO_TypeDef *ADS131M04_DRDY_Bank, uint16_t ADS131M04_DRDY_INT,
		TIM_HandleTypeDef *ADS131M04_CLK_TIM, uint32_t ADS131M04_CLK_CH,
		SPI_HandleTypeDef *ADIS16475_SPI, GPIO_TypeDef *ADIS16475_CS_Bank,
		uint16_t ADIS16475_CS_Pin, GPIO_TypeDef *ADIS16475_RESET_Bank,
		uint16_t ADIS16475_RESET_Pin, GPIO_TypeDef *ADIS16475_DRDY_Bank,
		uint16_t ADIS16475_DRDY_INT, GPIO_TypeDef *ADIS16475_SYNC_Bank,
		uint32_t ADIS16475_SYNC_Pin, uint16_t random_number) {

	// Perform initialization common to both units

	Unit->random_number = random_number;

	// Print flags
	Unit->USB_flag = 0;
	Unit->USB_busy_flag = 0;
	Unit->uSD_flag = 0;

	// Perform ADC initialization

	// Initialize sensors struct
	Unit->ADS131M04_SPI = ADS131M04_SPI;
	Unit->ADS131M04_CS_Bank = ADS131M04_CS_Bank;
	Unit->ADS131M04_CS_Pin = ADS131M04_CS_Pin;

	Unit->ADS131M04_RESET_Bank = ADS131M04_RESET_Bank;
	Unit->ADS131M04_RESET_Pin = ADS131M04_RESET_Pin;

	Unit->ADS131M04_DRDY_Bank = ADS131M04_DRDY_Bank;
	Unit->ADS131M04_DRDY_INT = ADS131M04_DRDY_INT;

	Unit->ADS131M04_CLK_TIM = ADS131M04_CLK_TIM;
	Unit->ADS131M04_CLK_CH = ADS131M04_CLK_CH;

	// Set ADC CS High
	HAL_GPIO_WritePin(Unit->ADS131M04_CS_Bank, Unit->ADS131M04_CS_Pin,
			GPIO_PIN_SET);

	// Reset ADC
	HAL_GPIO_WritePin(ADS131M04_RESET_Bank, ADS131M04_RESET_Pin,
			GPIO_PIN_RESET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(ADS131M04_RESET_Bank, ADS131M04_RESET_Pin, GPIO_PIN_SET);

	// Wait for reset to go into effect
	HAL_Delay(1000);

	// Check ADC ID
	read_ADC_reg(Unit, REG_ID);
	// Update Clock register with appropriate values - we are going for 4 ksps to have
	// external sync to the IMU (trust)
	write_ADC_reg(Unit, REG_CLOCK, 0b0000111100001110);
	// Potentially lock ADC register settings?

	/****************************
	 // Perform IMU initialization
	 ***************************/

	Unit->ADIS16475_SPI = ADIS16475_SPI;
	Unit->ADIS16475_CS_Bank = ADIS16475_CS_Bank;
	Unit->ADIS16475_CS_Pin = ADIS16475_CS_Pin;

	Unit->ADIS16475_RESET_Bank = ADIS16475_RESET_Bank;
	Unit->ADIS16475_RESET_Pin = ADIS16475_RESET_Pin;

	// Data ready - used for interrupt
	Unit->ADIS16475_DRDY_Bank = ADIS16475_DRDY_Bank;
	Unit->ADIS16475_DRDY_INT = ADIS16475_DRDY_INT;

	Unit->ADIS16475_SYNC_Bank = ADIS16475_SYNC_Bank;
	Unit->ADIS16475_SYNC_Pin = ADIS16475_SYNC_Pin;

	// USE DATAREADY PIN FROM IMU TO TRIGGER READ FROM ADC

	// OR JUST USE TWO SEPARATE QUEUES BUT IDK HOW THAT WOULD WORK with writing data to the uSD card

	// Set the interrupt to be triggered off of the IMU, have it simultaneously read the ADC
	// Store data like that
	// ADC isn't there for precision measurements (in terms of time), just for examining data that is transient / etc

	// CONFIGURE MSC_CTRL
	HAL_GPIO_WritePin(Unit->ADIS16475_CS_Bank, Unit->ADIS16475_CS_Pin,
			GPIO_PIN_SET);

	HAL_GPIO_WritePin(Unit->ADIS16475_RESET_Bank, Unit->ADIS16475_RESET_Pin,
			GPIO_PIN_RESET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(Unit->ADIS16475_RESET_Bank, Unit->ADIS16475_RESET_Pin,
			GPIO_PIN_SET);
	HAL_Delay(1000);

	write_IMU_reg(Unit, MSC_CTRL, 0b0000000011000101);

	// CONFIGURE DEC_RATE
	HAL_GPIO_WritePin(Unit->ADIS16475_CS_Bank, Unit->ADIS16475_CS_Pin,
			GPIO_PIN_SET);

	HAL_GPIO_WritePin(Unit->ADIS16475_RESET_Bank, Unit->ADIS16475_RESET_Pin,
			GPIO_PIN_RESET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(Unit->ADIS16475_RESET_Bank, Unit->ADIS16475_RESET_Pin,
			GPIO_PIN_SET);
	HAL_Delay(1000);

	write_IMU_reg(Unit, DEC_RATE, 0b0000000000000001);

	// Enable ADC CLKIN last
	Unit->ADS131M04_CLK_TIM->Instance->CCR2 = 7;
	HAL_TIM_PWM_Start(Unit->ADS131M04_CLK_TIM, Unit->ADS131M04_CLK_CH);

	memset(Unit->ADS131M04_tx, 0, 25);
	memset(Unit->ADS131M04_rx, 0, 25);

	// Initialize USB Transmit Array
	Unit->USB_tx_1[0] = 0xAB;
	Unit->USB_tx_1[1] = 0xBC;
	Unit->USB_tx_1[2] = 0xCD;
	Unit->USB_tx_1[3] = 0xDA;

	Unit->USB_tx_1[1020] = 0xAD;
	Unit->USB_tx_1[1021] = 0xDC;
	Unit->USB_tx_1[1022] = 0xCB;
	Unit->USB_tx_1[1023] = 0xBA;

	Unit->USB_tx_2[0] = 0xAB;
	Unit->USB_tx_2[1] = 0xBC;
	Unit->USB_tx_2[2] = 0xCD;
	Unit->USB_tx_2[3] = 0xDA;

	Unit->USB_tx_2[1020] = 0xAD;
	Unit->USB_tx_2[1021] = 0xDC;
	Unit->USB_tx_2[1022] = 0xCB;
	Unit->USB_tx_2[1023] = 0xBA;

	Unit->USB_tx = Unit->USB_tx_1;
	Unit->USB_tx_track = 1;

	Unit->USB_tx_index = 0;

	// Initialize uSD Transmit Array
	Unit->uSD_tx = Unit->uSD_tx_1;
	Unit->uSD_tx_track = 1;

	Unit->uSD_tx_index = 0;
	Unit->uSD_file_counter = 0;
	Unit->uSD_file_index = 0;

	return 0;
}

void read_ADC_reg(sensors *Unit, uint16_t register_number) {
	// Reset buffers to all 0
	memset(Unit->ADS131M04_tx, 0, 25);
	memset(Unit->ADS131M04_rx, 0, 25);

	// Set first word (24 bits) to read register command
	Unit->ADS131M04_tx[0] = MACRO_RREG(register_number, 1) >> 8;
	Unit->ADS131M04_tx[1] = MACRO_RREG(register_number, 1);

	// Transmit full frame with command
	HAL_GPIO_WritePin(Unit->ADS131M04_CS_Bank, Unit->ADS131M04_CS_Pin,
			GPIO_PIN_RESET);
	HAL_SPI_Transmit(Unit->ADS131M04_SPI, Unit->ADS131M04_tx, 18,
	HAL_MAX_DELAY);
	HAL_GPIO_WritePin(Unit->ADS131M04_CS_Bank, Unit->ADS131M04_CS_Pin,
			GPIO_PIN_SET);

	// Receive full frame with value
	HAL_GPIO_WritePin(Unit->ADS131M04_CS_Bank, Unit->ADS131M04_CS_Pin,
			GPIO_PIN_RESET);
	HAL_SPI_Receive(Unit->ADS131M04_SPI, Unit->ADS131M04_rx, 18,
	HAL_MAX_DELAY);
	HAL_GPIO_WritePin(Unit->ADS131M04_CS_Bank, Unit->ADS131M04_CS_Pin,
			GPIO_PIN_SET);
}

void write_ADC_reg(sensors *Unit, uint16_t register_number,
		uint16_t register_value) {
	// Reset buffers to all 0
	memset(Unit->ADS131M04_tx, 0, 25);
	memset(Unit->ADS131M04_rx, 0, 25);

	// Set first word (24 bits) to write register command
	Unit->ADS131M04_tx[0] = MACRO_WREG(register_number, 1) >> 8;
	Unit->ADS131M04_tx[1] = MACRO_WREG(register_number, 1);

	// Set second word (24 bits) to the register value
	Unit->ADS131M04_tx[3] = register_value >> 8;
	Unit->ADS131M04_tx[4] = register_value;

	// Transmit full frame with command
	HAL_GPIO_WritePin(Unit->ADS131M04_CS_Bank, Unit->ADS131M04_CS_Pin,
			GPIO_PIN_RESET);
	HAL_SPI_Transmit(Unit->ADS131M04_SPI, Unit->ADS131M04_tx, 18,
	HAL_MAX_DELAY);
	HAL_GPIO_WritePin(Unit->ADS131M04_CS_Bank, Unit->ADS131M04_CS_Pin,
			GPIO_PIN_SET);

	// Transmit full frame with value
	HAL_GPIO_WritePin(Unit->ADS131M04_CS_Bank, Unit->ADS131M04_CS_Pin,
			GPIO_PIN_RESET);
	HAL_SPI_Receive(Unit->ADS131M04_SPI, Unit->ADS131M04_rx, 18,
	HAL_MAX_DELAY);
	HAL_GPIO_WritePin(Unit->ADS131M04_CS_Bank, Unit->ADS131M04_CS_Pin,
			GPIO_PIN_SET);

	read_ADC_reg(Unit, register_number);

	if (Unit->ADS131M04_rx[0] == ((register_value >> 8) & 0xFF)
			&& Unit->ADS131M04_rx[1] == ((register_value) & 0xFF)) {
		int x = 0;
	}
}

void read_IMU_reg(sensors *Unit, uint16_t register_number) {

	// Reset buffers to all 0
	memset(Unit->ADIS16475_tx, 0, 25);
	memset(Unit->ADIS16475_rx, 0, 25);

	// Set first word (24 bits) to read register command
	Unit->ADIS16475_tx[0] = register_number;

	HAL_GPIO_WritePin(Unit->ADIS16475_CS_Bank, Unit->ADIS16475_CS_Pin,
			GPIO_PIN_RESET);
	HAL_SPI_Transmit(Unit->ADIS16475_SPI, Unit->ADIS16475_tx, 2, HAL_MAX_DELAY);
	HAL_GPIO_WritePin(Unit->ADIS16475_CS_Bank, Unit->ADIS16475_CS_Pin,
			GPIO_PIN_SET);

	HAL_Delay(1); // Replace with delay_us function later - need 30 us

	HAL_GPIO_WritePin(Unit->ADIS16475_CS_Bank, Unit->ADIS16475_CS_Pin,
			GPIO_PIN_RESET);
	HAL_SPI_Receive(Unit->ADIS16475_SPI, Unit->ADIS16475_rx, 2, HAL_MAX_DELAY);
	HAL_GPIO_WritePin(Unit->ADIS16475_CS_Bank, Unit->ADIS16475_CS_Pin,
			GPIO_PIN_SET);

	HAL_Delay(1); // Replace with delay_us function later - need 30 us
}

void write_IMU_reg(sensors *Unit, uint16_t register_number,
		uint16_t register_value) {
	// Reset buffers to all 0
	memset(Unit->ADIS16475_tx, 0, 25);
	memset(Unit->ADIS16475_rx, 0, 25);

	Unit->ADIS16475_tx[0] = ((0x80) | (register_number));
	Unit->ADIS16475_tx[1] = (register_value) & 0xFF;

	HAL_GPIO_WritePin(Unit->ADIS16475_CS_Bank, Unit->ADIS16475_CS_Pin,
			GPIO_PIN_RESET);
	HAL_SPI_Transmit(Unit->ADIS16475_SPI, Unit->ADIS16475_tx, 2, HAL_MAX_DELAY);
	HAL_GPIO_WritePin(Unit->ADIS16475_CS_Bank, Unit->ADIS16475_CS_Pin,
			GPIO_PIN_SET);

	HAL_Delay(1); // Replace with delay_us function later - need 30 us

	Unit->ADIS16475_tx[0] = ((0x80) | (register_number + 1));
	Unit->ADIS16475_tx[1] = (register_value >> 8) & 0xFF;

	HAL_GPIO_WritePin(Unit->ADIS16475_CS_Bank, Unit->ADIS16475_CS_Pin,
			GPIO_PIN_RESET);
	HAL_SPI_Transmit(Unit->ADIS16475_SPI, Unit->ADIS16475_tx, 2, HAL_MAX_DELAY);
	HAL_GPIO_WritePin(Unit->ADIS16475_CS_Bank, Unit->ADIS16475_CS_Pin,
			GPIO_PIN_SET);

	HAL_Delay(1); // Replace with delay_us function later - need 30 us

	read_IMU_reg(Unit, register_number);

	if (Unit->ADIS16475_rx[0] == ((register_value >> 8) & 0xFF)
			&& Unit->ADIS16475_rx[1] == ((register_value) & 0xFF)) {
		int x = 0;
	}

	HAL_Delay(1); // Replace with delay_us function later - need 30 us
}

void read_IMU_values(sensors *Unit) {

	Unit->ADIS16475_tx[0] = BURST_START;

	HAL_GPIO_WritePin(Unit->ADIS16475_CS_Bank, Unit->ADIS16475_CS_Pin,
			GPIO_PIN_RESET);
	HAL_SPI_TransmitReceive_DMA(Unit->ADIS16475_SPI, Unit->ADIS16475_tx,
			Unit->ADIS16475_rx, 22);
}

void read_ADC_values(sensors *Unit) {
	HAL_GPIO_WritePin(Unit->ADS131M04_CS_Bank, Unit->ADS131M04_CS_Pin,
			GPIO_PIN_RESET);
	HAL_SPI_Receive(Unit->ADS131M04_SPI, Unit->ADS131M04_rx, 18,
	HAL_MAX_DELAY);
	HAL_GPIO_WritePin(Unit->ADS131M04_CS_Bank, Unit->ADS131M04_CS_Pin,
			GPIO_PIN_SET);
}
